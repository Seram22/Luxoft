﻿using Autofac;
using System;

namespace Runner
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var builder = new ContainerBuilder();

            builder.RegisterType<SumOfMultiple.SumOfMultipleService>().As<SumOfMultiple.ISumOfMultiple>();
            builder.RegisterType<SequenceAnalysis.SequenceAnalysisService>().As<SequenceAnalysis.ISequenceAnalysis>();

            using (var container = builder.Build())
            {
                while (true)
                {
                    Console.WriteLine("\nWhich problem do you want to solve?\n");
                    Console.WriteLine("1. Find the sum of all natural numbers that are a multiple of 3 or 5");
                    Console.WriteLine("2. Find the uppercase words in a string\n");
                    var choice = Console.ReadLine();
                    switch (choice)
                    {
                        case "1":
                            var sumOfMultipleService = container.Resolve<SumOfMultiple.ISumOfMultiple>();
                            Console.WriteLine("Enter the limit:");
                            var limit = int.Parse(Console.ReadLine());
                            var result = sumOfMultipleService.Calculate(limit);
                            Console.WriteLine($"Sum of all natural numbers that are a multiple of 3 or 5 below {limit} is {result}");
                            break;
                        case "2":
                            var sequenceAnalysisService = container.Resolve<SequenceAnalysis.ISequenceAnalysis>();
                            Console.WriteLine("Enter the string:");
                            var input = Console.ReadLine();
                            var output = sequenceAnalysisService.GetUppercaseWordsSorted(input);
                            Console.WriteLine($"The uppercase words sorted are {output}");
                            break;
                        default:
                            Console.WriteLine("Invalid choice. Please try again.\n");
                            break;
                    }
                }
            }
        }
    }
}
