﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SumOfMultiple
{
    public interface ISumOfMultiple
    {
        int Calculate(int limit);
    }
}
