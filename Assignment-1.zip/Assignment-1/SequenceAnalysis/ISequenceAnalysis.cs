﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SequenceAnalysis
{
    public interface ISequenceAnalysis
    {
        string GetUppercaseWordsSorted(string input);
    }
}
