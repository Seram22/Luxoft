﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SequenceAnalysis
{
    public class SequenceAnalysisService : ISequenceAnalysis
    {
        public string GetUppercaseWordsSorted(string input)
        {
            var words = input.Split(' ');
            var uppercaseWords = words.Where(w => w.Any(char.IsUpper));
            var uppercaseChars = uppercaseWords.SelectMany(w => w.Where(char.IsUpper));
            var sortedChars = uppercaseChars.OrderBy(c => c);
            return new string(sortedChars.ToArray());
        }
    }
}
