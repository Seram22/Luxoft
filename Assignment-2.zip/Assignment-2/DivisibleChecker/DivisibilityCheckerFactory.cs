﻿using Autofac;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace DivisibleChecker
{
    internal class DivisibilityCheckerFactory
    {
        private static readonly Autofac.IContainer Container;

        static DivisibilityCheckerFactory()
        {
            var builder = new ContainerBuilder();
            builder.RegisterType<DivisibilityChecker>().As<IDivisibilityChecker<long>>();
            Container = builder.Build();
        }

        public static IDivisibilityChecker<T> GetChecker<T>()
            {
            return Container.Resolve<IDivisibilityChecker<T>>();
        }
    }
}
