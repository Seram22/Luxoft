﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DivisibleChecker
{
    internal interface IDivisibilityChecker<T>
    {
        int IsXDivisibleByY(T x, T y);
    }
}
