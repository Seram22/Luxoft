﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DivisibleChecker
{
    internal class DivisibilityChecker : IDivisibilityChecker<long>
    {
        public int IsXDivisibleByY(long x, long y)
        {
            int remainder = (int)(x % y);
            int mask = ((remainder | (remainder - 1)) >> (sizeof(long) * 8 - 1));
            return (mask != 0) ? 1 : 0;
        }
    }
}
