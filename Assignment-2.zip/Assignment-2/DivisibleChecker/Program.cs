﻿using System;

namespace DivisibleChecker
{
    internal class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Let's check the divisibilty of the numbers\n");
                Console.WriteLine("Enter the first number:");
                var x = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter the second number:");
                var y = int.Parse(Console.ReadLine());
                int result = DivisibilityCheckerFactory.GetChecker<long>().IsXDivisibleByY(x, y); 
                Console.WriteLine(result);
            }
        }
    }
}
